enable_managed_security_services = false
alert_email = "sy710481@gmail.com"
cloudtrail_bucket_name = "securephotoshare-bucket-cloudtrail"
